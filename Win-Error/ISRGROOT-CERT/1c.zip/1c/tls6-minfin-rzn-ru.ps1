$cert = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2("tls6.minfin-rzn.ru_2025.cer")
[System.Security.Cryptography.X509Certificates.X509Store]::OpenFlags::ReadWrite
$store = New-Object System.Security.Cryptography.X509Certificates.X509Store("My", "Root", "CA", "AddressBook", "TrustedPublisher", "AuthRoot")
$store.Open()
if ($cert.Extensions | Where-Object { $_.Oid.FriendlyName -eq "Server Authentication" }) {
	$store.Add($cert)
} elseif ($cert.Issuer -eq $cert.Subject) {
	$store.Add($cert)
} else {
	$store.Add($cert)
}
$store.Close()
