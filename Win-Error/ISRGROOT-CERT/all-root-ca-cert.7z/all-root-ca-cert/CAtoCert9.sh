#!/bin/bash

for certDB in $(find ~/ -name "cert9.db"); do
	certdir=$(dirname ${certDB});
	for cert_files in ./*.p7b; do
		certname=$(basename "${cert_files}" | sed 's/.p7b//g')
		openssl x509 -inform PEM -in "${certname}.p7b" -out "${certname}.crt"
		certutil -A -n "${certname}" -t "TCu,Cu,Tu" -i "${cert_files}" -d sql:${certdir}
	done
done

for certDB in $(find ~/ -name "cert8.db"); do
	certdir=$(dirname ${certDB});
	for cert_files in ./*.p7b; do
		certname=$(basename "${cert_files}" | sed 's/.p7b//g')
		certutil -A -n "${certname}" -t "TCu,Cu,Tu" -i "${cert_files}" -d sql:${certdir}
	done
done
